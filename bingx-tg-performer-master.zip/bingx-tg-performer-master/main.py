import asyncio
import functools
import logging
import os

from signal import SIGINT, SIGTERM

from src.tg_bingx_bot.manager import Manager

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

async def shutdown(loop, manager):
    """Cleanup tasks tied to the service's shutdown."""
    logging.info(f"Received exit signal...")

    await manager.close_connections()

    logging.info("Closing database connections")
    logging.info("Nacking outstanding messages")
    tasks = [t for t in asyncio.all_tasks() if t is not
             asyncio.current_task()]

    [task.cancel() for task in tasks]

    logging.info(f"Cancelling {len(tasks)} outstanding tasks")
    await asyncio.gather(*tasks)
    logging.info(f"Flushing metrics")
    loop.stop()

if __name__ == '__main__':
    logger.info("Start bot")
    manager = Manager('config.toml')

    loop = asyncio.get_event_loop()

    # for linux
    logger.info(f"OS: {os.name}")
    if os.name == 'posix':
        for signal in [SIGINT, SIGTERM]:
            loop.add_signal_handler(signal, lambda: asyncio.create_task(shutdown(loop, manager)))
    try:
        loop.run_until_complete(manager.start(loop))
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt")
    finally:
        # Perform cleanup tasks
        try:
            logger.info("Shutdown")
            loop.run_until_complete(shutdown(loop, manager))
        except asyncio.exceptions.CancelledError:
            pass


