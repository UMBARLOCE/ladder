import asyncio
import datetime
import logging
from dataclasses import dataclass
import random
from typing import NoReturn, Optional, Literal

import ccxt.pro as ccxt
from ccxt import BadRequest, ExchangeClosedByUser, ExchangeError

from src.tg_bingx_bot.dataclasses.direction_enum import Direction
from src.tg_bingx_bot.dataclasses.key_pair import KeyPair
from src.tg_bingx_bot.dataclasses.market import Market
from src.tg_bingx_bot.dataclasses.position_state_enum import PositionState
from src.tg_bingx_bot.dataclasses.signal import Signal
from src.tg_bingx_bot.dataclasses.bingx_connection import ExchangeConnection
from src.tg_bingx_bot.dataclasses.position import Position
from src.tg_bingx_bot.retry_decorator import retry
from src.tg_bingx_bot.utils import check_to_range, round_to_precision

logger = logging.getLogger("asyncio")
logger.setLevel("INFO")

'''
1 таргет стоп переносим стоп на цену входа
2 таргет закрываем половину позиции 
3 таргет стоп переносим на первый таргет
4 таргет закрываем половину позиции (25% от изначального объема),
включаем трейлинг стоп
'''

SIGNAL_RECEIVE_TIMEOUT = 60
UPDATE_MARKETS_MAP_DELAY = 300
UPDATE_EMPTY_MARKETS_MAP_DELAY = 10

class Strategy:

    def __init__(self, trailing_stop_percent: float, signal_lifetime: int):
        self.trailing_stop_coef = trailing_stop_percent
        self.signal_lifetime = signal_lifetime

        self._connections: list[ExchangeConnection] = []
        self._markets_map: dict[str, Market] = {}
        self._watching_symbols = []

    async def connect_to_keys(self, keys: list[KeyPair]):

        for key_pair in keys:
            try:
                connection = ccxt.bingx({
                    'apiKey': key_pair.public,
                    'secret': key_pair.private,
                    'options': {
                        'adjustForTimeDifference': True,
                        'defaultType': 'swap',
                    }
                })

                logger.info(f"Close all positions for {key_pair.name}")
                await connection.close_all_positions()

                # Set hedge mode on symbol
                await connection.set_position_mode(hedged=True)

                self._connections.append(ExchangeConnection(
                    name=key_pair.name,
                    deposit_percent_per_position=key_pair.deposit_percent_per_position,
                    leverage=key_pair.leverage,
                    exchange=connection,
                    actual_signals={},
                    positions={}
                ))
            except Exception as exc:
                logger.error(f"Problem with keys {key_pair.name} whose public is begin as {key_pair.public[:10]}: {exc}")

    async def close(self):
        tasks = [self.close_account_positions(conn) for conn in self._connections]
        await asyncio.gather(*tasks)

        # sleep for close positions task completed
        await asyncio.sleep(1)

        tasks = [conn.exchange.close() for conn in self._connections]
        await asyncio.gather(*tasks)

    async def close_account_positions(self, conn: ExchangeConnection):
        logger.info(f"Close all positions for {conn.name}")
        await conn.exchange.close_all_positions()

    def remove_watch_symbol(self, symbol: str):
        if symbol not in self._watching_symbols:
            return
        if symbol in [sym for conn in self._connections for sym in conn.positions.keys()] or \
                symbol in [sym for conn in self._connections for sym in conn.actual_signals.keys()]:
            return

        logger.info(f"Remove watching symbol {symbol}")
        self._watching_symbols.remove(symbol)

    async def handle_signal(self, signal: Signal):
        logger.info(signal)

        if datetime.datetime.now().timestamp() - signal.receive_time.timestamp() > SIGNAL_RECEIVE_TIMEOUT:
            logger.info(f"Signal for {signal.symbol} received too late, ignored")
            return

        for conn in self._connections:
            await self.process_new_signal(conn, signal)

        if len(self._connections) != 0 and signal.symbol not in self._watching_symbols:
            if self.get_exc_symbol(signal.symbol) == '':
                logger.warning(f"Not found symbol {signal.symbol} for watching")
                return

            self._watching_symbols.append(signal.symbol)
            asyncio.create_task(self._watch_for_symbol(signal.symbol, self._connections[0]))

    async def process_new_signal(self, conn: ExchangeConnection, signal: Signal) -> None:
        if position := conn.positions.get(signal.symbol, None):
            await self.close_position(conn, position)
            logger.info(f'Close position for {signal.symbol}')

        conn.actual_signals[signal.symbol] = signal

    @staticmethod
    def check_state_change_by_target(ohlcv: list, signal: Signal, current_state: PositionState) -> PositionState:
        _, _, high, low, _, _ = ohlcv[0]

        price = high if signal.direction == Direction.BUY else low
        use_up_bound = signal.direction == Direction.BUY
        new_state = current_state

        if new_state == PositionState.Entry:
                if check_to_range(price,
                                  None if use_up_bound else signal.target_1_price,
                                  signal.target_1_price if use_up_bound else None):
                    # 1 таргет стоп переносим на цену входа
                    new_state = PositionState.Target_1

        if new_state == PositionState.Target_1:
                if check_to_range(price,
                                  None if use_up_bound else signal.target_2_price,
                                  signal.target_2_price if use_up_bound else None):
                    # 2 таргет закрываем половину позиции, стоп на цену входа
                    new_state = PositionState.Target_2

        if new_state == PositionState.Target_2:
                if check_to_range(price,
                                  None if use_up_bound else signal.target_3_price,
                                  signal.target_3_price if use_up_bound else None):
                    # 3 таргет стоп переносим на первый таргет
                    new_state = PositionState.Target_3

        if new_state == PositionState.Target_3:
                if check_to_range(price,
                                  None if use_up_bound else signal.target_4_price,
                                  signal.target_4_price if use_up_bound else None):
                    # 4 таргет закрываем половину позиции (25% от изначального объема),
                    # включаем трейлинг стоп
                    logger.info(f"Target 4 for signal {signal.symbol}")
                    new_state = PositionState.Target_4

        return new_state

    async def handle_new_state(self, conn: ExchangeConnection, position: Position, new_state: PositionState) -> None:

        market = self._markets_map[position.symbol]

        # noinspection PyTypeChecker
        exit_side: Literal['buy', 'sell'] = 'sell' if position.signal.direction == Direction.BUY else 'buy'

        position.state = new_state
        match new_state:
            case PositionState.Target_1:
                # 1 таргет стоп переносим на цену входа
                await self._handle_switch_to_target_1(
                    conn, exit_side, market, position)

            case PositionState.Target_2:
                # 2 таргет закрываем половину позиции
                await self._handle_switch_to_target_2(
                    conn, exit_side, market, position)

            case PositionState.Target_3:
                # 3 таргет стоп переносим на первый таргет
                await self._handle_switch_to_target_3(
                    conn, exit_side, market, position)

            case PositionState.Target_4:
                # 4 таргет закрываем половину позиции (25% от изначального объема),
                # включаем трейлинг стоп
                await self._handle_switch_to_target_4(
                    conn, exit_side, market, position)

    async def _handle_switch_to_target_1(self, conn, exit_side, market, position):
        await self.cancel_order(conn, position.stop_loss_id, self.get_exc_symbol(position.symbol))

        amount = (await conn.exchange.fetch_position(self.get_exc_symbol(position.symbol)))['contracts']
        if amount is None:
            logger.info(f"Position {conn.name} {position.symbol} is already closed")
            return

        amount = round_to_precision(amount, market.amount_precision)

        logger.info(f"T1 Move sl to {position.entry_price} with {amount} "
                    f"for {position.symbol} {conn.name}.")

        result = await conn.exchange.create_stop_loss_order(
            symbol=self.get_exc_symbol(position.symbol),
            side=exit_side,
            stopLossPrice=position.entry_price,
            type='market',
            amount=amount,
            params={'reduceOnly': True}
        )
        position.stop_loss_id = result['id']

    async def _handle_switch_to_target_2(self, conn, exit_side, market, position):
        pass

    async def _handle_switch_to_target_3(self, conn, exit_side, market, position):
        await self.cancel_order(conn, position.stop_loss_id, self.get_exc_symbol(position.symbol))
        amount = (await conn.exchange.fetch_position(self.get_exc_symbol(position.symbol)))['contracts']
        if amount is None:
            logger.info(f"Position {conn.name} {position.symbol} is already closed")
            return

        amount = round_to_precision(amount, market.amount_precision)

        logger.info(f"T3 Move sl to {position.signal.target_1_price} {amount} "
                    f"for {position.symbol} {conn.name}. ")

        result = await conn.exchange.create_stop_loss_order(
            symbol=self.get_exc_symbol(position.symbol),
            side=exit_side,
            type='market',
            stopLossPrice=position.signal.target_1_price,
            amount=amount,
            params={'reduceOnly': True}
        )
        position.stop_loss_id = result['id']

    async def _handle_switch_to_target_4(self, conn, exit_side, market, position):
        await self.cancel_order(conn, position.stop_loss_id, self.get_exc_symbol(position.symbol))
        amount = (await conn.exchange.fetch_position(self.get_exc_symbol(position.symbol)))['contracts']
        if amount is None:
            logger.info(f"Position {conn.name} {position.symbol} is already closed")
            return

        amount = round_to_precision(amount, market.amount_precision)

        logger.info(f"T4 Place trailing stop with {amount} "
                    f"for {position.symbol} {conn.name}. ")

        result = await conn.exchange.create_trailing_percent_order(
            symbol=self.get_exc_symbol(position.symbol),
            side=exit_side,
            type='market',
            amount=amount,
            trailingPercent=self.trailing_stop_coef,
            params={'reduceOnly': True}
        )
        position.trailing_stop_id = result['id']

    async def cancel_order(self, conn, order_id, symbol):
        try:
            await conn.exchange.cancel_order(order_id, symbol)
        except BadRequest as exc:
            logger.error(f"Problem with cancelling stop loss for {conn.name} {symbol}: {exc}")
        except Exception as exc:
            logger.error(f"Problem with cancelling stop loss for {conn.name} {symbol}: {exc}",
                         exc_info=True)

    async def _handle_position(self, conn: ExchangeConnection, ohlcv: list, position: Position):
        try:
            state = self.check_state_change_by_target(ohlcv, position.signal, position.state)
            if position.state != state:
                logger.info(f"New state of {position.symbol} {conn.name}: {state}")
                await self.handle_new_state(conn, position, state)
        except Exception as exc:
            logger.error(f"Error on handling position {position.symbol} {conn.name}: {exc}", exc_info=True)
            await self.close_position(conn, position)

    async def _handle_actual_signal(self, conn: ExchangeConnection, ohlcv: list, signal: Signal):
        try:
            await self._check_to_enter_by_signal(conn, ohlcv, signal)

        except BadRequest as exc:
            logger.error(f"Problem on handling position for {conn.name} {signal.symbol}: {exc}")
        except Exception as exc:
            logger.error(f"Error on handling position for {conn.name} {signal.symbol}: {exc}", exc_info=True)

    async def _check_to_enter_by_signal(self, conn: ExchangeConnection, ohlcv: list, signal: Signal):
        _, _, high, low, close, _ = ohlcv[0]

        if datetime.datetime.now().timestamp() - signal.receive_time.timestamp() > self.signal_lifetime:
            logger.info(f"Signal for {signal.symbol} is too old, waiting is stopped")
            conn.actual_signals.pop(signal.symbol)
            self.remove_watch_symbol(signal.symbol)
            return

        # check the exact range or complete overlap of the candle range
        if check_to_range(close, signal.max_enter_price, signal.min_enter_price) \
                or high > signal.max_enter_price and low < signal.min_enter_price:

            market = self._markets_map[signal.symbol]

            conn.actual_signals.pop(market.symbol)

            is_valid_position, precised_position_size = await self._verify_enter_conditions(conn, close, market, signal)
            if not is_valid_position:
                return

            # Set hedge mode, leverage from settings and cross mode
            await self.set_margin_settings_on_symbol(conn, market)

            logger.info(f"Enter to position on {signal.symbol}")

            # enter to position
            await conn.exchange.create_market_order(
                symbol=market.exc_symbol,
                side='buy' if signal.direction == Direction.BUY else 'sell',
                amount=precised_position_size
            )

            sl, tp_1, tp_2 = await self.place_stop_orders(
                conn=conn,
                exit_side='sell' if signal.direction == Direction.BUY else 'buy',
                market=market,
                precised_position_size=precised_position_size,
                signal=signal
            )

            conn.positions[signal.symbol] = Position(
                symbol=market.symbol,
                signal=signal,
                entry_price=close,
                state=PositionState.Entry,
                position_full_amount=precised_position_size,
                take_profit_1_id=tp_1['id'],
                take_profit_2_id=tp_2['id'],
                stop_loss_id=sl['id'],
                trailing_stop_id=None
            )



    async def _verify_enter_conditions(self, conn: ExchangeConnection, close: float,
                                           market: Market, signal: Signal) -> (bool, float):
        """
        This method verifies the conditions for entering a position.

        :param conn: The ExchangeConnection object.
        :type conn: ExchangeConnection
        :param close: The closing price of the asset.
        :type close: float
        :param market: The Market object.
        :type market: Market
        :param signal: The Signal object.
        :type signal: Signal
        :return: A tuple containing a boolean indicating whether the conditions are met and the position size.
        :rtype: (bool, float)
        """
        exact_position_cost = await self.position_size_for_connection(conn)
        if exact_position_cost == 0:
            logger.warning(f"Insufficient balance")
            return False, 0
        if exact_position_cost is None:
            logger.warning("Failed to fetch available balance.")
            return False, 0

        precised_position_size = round_to_precision(exact_position_cost / close, market.amount_precision)

        if exact_position_cost < market.min_cost:
            logger.warning(f'Insufficient balance {conn.name}: cost {exact_position_cost}'
                           f' to enter a position less than exchange limit {market.min_cost}. {conn.actual_signals.keys()}')
            self.remove_watch_symbol(signal.symbol)
            return False, 0

        if round_to_precision(precised_position_size * 0.25, market.amount_precision) <= market.min_cost:
            logger.warning(f'Insufficient balance {conn.name}: {precised_position_size}, '
                           f'The position is too small to place a take profit on 25% of the position.')
            self.remove_watch_symbol(signal.symbol)
            return False, 0

        return True, precised_position_size

    async def place_stop_orders(self, conn, exit_side, market, precised_position_size, signal):
        # place stop losses
        sl = await self.place_sl(conn, exit_side, market, precised_position_size, signal)
        # place take profits
        tp_1 = await self.place_tp1(conn, exit_side, market, precised_position_size, signal)
        tp_2 = await self.place_tp2(conn, exit_side, market, precised_position_size, signal)
        logger.info(f"{conn.name} {signal.symbol} TP1: {tp_1['id']}, TP2: {tp_2['id']}, SL: {sl['id']}")
        return sl, tp_1, tp_2

    @retry(times=3, exceptions=(ExchangeError))
    async def place_tp2(self, conn, exit_side, market, precised_position_size, signal):
        logger.info(f"Place take profit 2 for {conn.name} {signal.symbol} "
                    f"on {round_to_precision(signal.target_4_price, market.price_precision)} "
                    f"for amount {round_to_precision(precised_position_size * 0.25, market.amount_precision)}")
        tp_2 = await conn.exchange.create_limit_order(
            symbol=market.exc_symbol,
            side=exit_side,
            amount=round_to_precision(precised_position_size * 0.25, market.amount_precision),
            price=round_to_precision(signal.target_4_price, market.price_precision),
            params={'reduceOnly': True},
        )
        return tp_2

    @retry(times=3, exceptions=(ExchangeError))
    async def place_tp1(self, conn, exit_side, market, precised_position_size, signal):
        logger.info(f"Place take profit 1 for {conn.name} {signal.symbol} "
                    f"on {round_to_precision(signal.target_2_price, market.price_precision)} "
                    f"for amount {round_to_precision(precised_position_size * 0.5, market.amount_precision)}")
        tp_1 = await conn.exchange.create_limit_order(
            symbol=market.exc_symbol,
            side=exit_side,
            amount=round_to_precision(precised_position_size * 0.5, market.amount_precision),
            price=round_to_precision(signal.target_2_price, market.price_precision),
            params={'reduceOnly': True}
        )
        return tp_1

    @retry(times=3, exceptions=(ExchangeError))
    async def place_sl(self, conn, exit_side, market, precised_position_size, signal):
        logger.info(f"Place stop loss for {conn.name} {signal.symbol} "
                    f"on {round_to_precision(signal.stop_loss_price, market.price_precision)} "
                    f"for amount {precised_position_size}")

        sl = await conn.exchange.create_stop_loss_order(
            symbol=market.exc_symbol,
            type='market',
            side=exit_side,
            amount=precised_position_size,
            stopLossPrice=round_to_precision(signal.stop_loss_price, market.price_precision, use_ceil=True),
            params={'reduceOnly': True}
        )
        return sl

    async def set_margin_settings_on_symbol(self, conn, market):
        # Set leverage on symbol
        coro_long_leverage = conn.exchange.set_leverage(leverage=conn.leverage, symbol=market.exc_symbol,
                                                        params={"marginMode": "cross", 'side': 'LONG'})
        coro_short_leverage = conn.exchange.set_leverage(leverage=conn.leverage, symbol=market.exc_symbol,
                                                         params={"marginMode": "cross", 'side': 'SHORT'})
        # Set cross margin mode on symbol
        coro_margin_mode = conn.exchange.set_margin_mode(marginMode="cross", symbol=market.exc_symbol)
        await asyncio.gather(coro_short_leverage, coro_long_leverage, coro_margin_mode)

    async def _watch_for_symbol(self, symbol: str, conn: ExchangeConnection):
        exc_symbol = self.get_exc_symbol(symbol)

        while symbol in self._watching_symbols:
            try:
                ohlcv = await conn.exchange.watch_ohlcv(exc_symbol, '1m')
                await self._handle_ohlcv(symbol, ohlcv)
            except ConnectionResetError:
                logger.warning(f'Connection reset error on watching OHLCV for symbol {exc_symbol}')
                await asyncio.sleep(5)
            except Exception as exc:
                logger.warning(f'Exception in watch for symbol {exc_symbol}: {exc}', exc_info=True)
                await asyncio.sleep(5)

    async def start_watching_for_orders(self) -> NoReturn:
        tasks = [asyncio.create_task(self._watch_for_orders_of_connection(conn)) for conn in self._connections]
        await asyncio.gather(*tasks)

    async def _watch_for_orders_of_connection(self, conn: ExchangeConnection):
        while True:
            try:
                order_update = await conn.exchange.watch_orders()
                for order in order_update:
                    await self._handle_order_update(conn, order)
            except ExchangeClosedByUser:
                pass
            except Exception as exc:
                logger.warning(f'Exception in watch for symbol: {exc}', exc_info=True)
                await asyncio.sleep(5)

    async def _handle_ohlcv(self, symbol: str, ohlcv):
        tasks = []
        for conn in self._connections:
            if symbol in conn.actual_signals:
                tasks.append(asyncio.create_task(self._handle_actual_signal(conn, ohlcv, conn.actual_signals[symbol])))
            if symbol in conn.positions:
                tasks.append(asyncio.create_task(self._handle_position(conn, ohlcv, conn.positions[symbol])))
        await asyncio.gather(*tasks)

    async def _handle_order_update(self, conn: ExchangeConnection, order_update: dict):
        logger.info(f'order update {order_update}')

        if order_update.get('status', '').lower() not in ['closed', 'triggered', 'canceled', 'filled']:
            return

        symbol = self.get_from_exc_symbol(order_update.get('symbol', ''))

        if position := conn.positions.get(symbol, None):
            position_amount = (await conn.exchange.fetch_position(self.get_exc_symbol(symbol)))['contracts']
            if position_amount is None:
                logger.info(f"Closed position on {position.symbol}")
                await conn.exchange.cancel_all_orders(self.get_exc_symbol(symbol))
                conn.positions.pop(position.symbol)
                self.remove_watch_symbol(position.symbol)

            else:
                logger.info(f"Position_amount for {order_update.get('symbol', '')} is {position_amount}')")

    async def start_updating_markets_loop(self):
        while True:
            try:
                await self.update_markets_map()
                if self._markets_map != {}:
                    await asyncio.sleep(UPDATE_MARKETS_MAP_DELAY)
                else:
                    await asyncio.sleep(UPDATE_EMPTY_MARKETS_MAP_DELAY)
            except Exception as exc:
                logger.warning(f'Exception in updating markets loop: {exc}', exc_info=True)
                await asyncio.sleep(5)

    async def update_markets_map(self):
        if len(self._connections) == 0:
            return

        choose_conn_to_request = random.randint(0, len(self._connections) - 1)
        connection = self._connections[choose_conn_to_request]

        markets = await connection.exchange.fetch_markets()
        if type(markets) != list:
            logger.warning(f'Problem with markets loading: {markets}')
            return

        self._markets_map = await self.create_markets_map(markets)

    async def create_markets_map(self, markets):
        markets_map = {}
        for market in markets:
            try:
                if ':' not in market['symbol']:
                    continue
                symbol = market['id'].replace('-', '')
                markets_map[symbol] = Market(
                    symbol=symbol,
                    exc_symbol=market['symbol'],
                    price_precision=market['precision']['price'],
                    amount_precision=market['precision']['amount'],
                    min_cost=market['limits']['cost']['min'],
                )
            except Exception as exc:
                logger.warning(f'Problem with loading market: {exc}', exc_info=True)
        return markets_map

    async def position_size_for_connection(self, conn: ExchangeConnection) -> Optional[float]:
        response = await conn.exchange.fetch_balance()
        position_size = self.calculate_position_size(response, conn.deposit_percent_per_position, leverage=conn.leverage)
        return position_size

    def calculate_position_size(self, response: dict, deposit_percent_per_position: float, leverage: int) -> Optional[float]:
        if response.get('info', {}).get('code', '') != '0' or response.get("USDT", None) == None:
            logger.warning(f"Problem with fetching balance: {response}")
            return

        usdt_free_balance = response['USDT']['free']

        position_size = usdt_free_balance * deposit_percent_per_position * leverage
        return position_size

    async def close_position(self, conn: ExchangeConnection, position: Position):
        exc_symbol = self.get_exc_symbol(position.symbol)
        result = await conn.exchange.close_position(exc_symbol)
        await conn.exchange.cancel_all_orders(exc_symbol)
        logger.info(f"Close position {conn.name} {position.symbol}: {result}")

    def get_exc_symbol(self, symbol):
        if market := self._markets_map.get(symbol, None):
            return market.exc_symbol
        return ''

    def get_from_exc_symbol(self, symbol):
        for market in self._markets_map.values():
            if market.exc_symbol == symbol:
                return market.symbol
        return ''
