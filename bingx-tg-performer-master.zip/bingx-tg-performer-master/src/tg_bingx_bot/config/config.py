from dataclasses import dataclass

from src.tg_bingx_bot.dataclasses.key_pair import KeyPair


@dataclass
class Config:
    bot_token: str
    channel_id: int
    keys: list[KeyPair]
    trailing_stop_distance_percent: float
    checking_delay: float
    signal_lifetime: int
