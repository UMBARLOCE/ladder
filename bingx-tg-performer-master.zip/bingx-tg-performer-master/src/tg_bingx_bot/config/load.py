import tomllib

from src.tg_bingx_bot.config.config import Config
from src.tg_bingx_bot.dataclasses.key_pair import KeyPair


def load_config(path: str) -> Config:
    with open(path, "rb") as f:
        data = tomllib.load(f)
    config = Config(
        bot_token=data['telegram']['bot_token'],
        channel_id=data['telegram']['signal_channel_id'],
        keys=[KeyPair(
            name=keys['name'],
            public=keys['public'],
            deposit_percent_per_position=keys['deposit_percent_per_position'] / 100,
            leverage=keys['leverage'],
            private=keys['private']
        ) for keys in data['exchange']['keys']],
        trailing_stop_distance_percent=data['strategy']['trailing_stop_distance_percent'],
        checking_delay=data['strategy']['checking_delay'],
        signal_lifetime=data['strategy']['signal_lifetime'],
    )
    return config
