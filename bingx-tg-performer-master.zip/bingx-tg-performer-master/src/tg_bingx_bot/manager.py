import asyncio
import logging
from typing import NoReturn

from src.tg_bingx_bot.strategy import Strategy
from src.tg_bingx_bot.config.load import load_config
from src.tg_bingx_bot.dataclasses.signal import Signal
from src.tg_bingx_bot.signals_listener import Listener

logger = logging.getLogger(__name__)


class Manager:
    def __init__(self, config_path: str):
        self._config = load_config(config_path)
        self._listener = Listener(self._config.bot_token, self._config.channel_id, self._handle_signal)
        self._strategy = Strategy(self._config.trailing_stop_distance_percent,
                                  self._config.signal_lifetime)

    async def start(self, loop: asyncio.AbstractEventLoop):
        try:
            await self._strategy.connect_to_keys(self._config.keys)
            await self._strategy.update_markets_map()
            listen_coro = asyncio.create_task(self._listener.start_polling(loop))
            watching_order_coro = asyncio.create_task(self._strategy.start_watching_for_orders())
            updating_markets_coro = asyncio.create_task(self._strategy.start_updating_markets_loop())
            await asyncio.gather(listen_coro, watching_order_coro, updating_markets_coro)

        except KeyboardInterrupt:
            logger.info("Exit from manager...")
        except Exception as exc:
            logger.critical(f"Exception in manager: {exc}", exc_info=True)

    async def close_connections(self):
        await self._strategy.close()


    async def _handle_signal(self, signal: Signal):
        await self._strategy.handle_signal(signal)
