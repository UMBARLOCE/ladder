import math
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP


def check_to_range(value: float, up_bound: float = None, down_bound: float = None):
    if up_bound is not None and value > up_bound:
        return False
    if down_bound is not None and value < down_bound:
        return False
    return True


def round_to_precision(value: float, precision: float, use_ceil: bool = False):
    if value is None or precision is None:
        return None

    value = Decimal(str(value))
    precision = Decimal(str(precision))

    if use_ceil:
        result = (value / precision).quantize(Decimal('1'), rounding=ROUND_CEILING) * precision
    else:
        result = (value / precision).quantize(Decimal('1'), rounding=ROUND_HALF_UP) * precision

    return float(result)
