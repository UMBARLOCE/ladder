from dataclasses import dataclass
from typing import Optional

from src.tg_bingx_bot.dataclasses.position_state_enum import PositionState

from src.tg_bingx_bot.dataclasses.signal import Signal


@dataclass
class Position:
    symbol: str
    signal: Signal
    entry_price: float
    state: PositionState
    stop_loss_id: str
    take_profit_1_id: str
    take_profit_2_id: str
    trailing_stop_id: Optional[str]
    position_full_amount: float