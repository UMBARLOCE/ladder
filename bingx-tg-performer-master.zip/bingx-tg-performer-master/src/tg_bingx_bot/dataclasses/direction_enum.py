import enum


class Direction(enum.Enum):
    BUY = 'buy',
    SELL = 'sell'
