from dataclasses import dataclass

@dataclass()
class Market:
    symbol: str
    exc_symbol: str
    amount_precision: float
    price_precision: float
    min_cost: float
