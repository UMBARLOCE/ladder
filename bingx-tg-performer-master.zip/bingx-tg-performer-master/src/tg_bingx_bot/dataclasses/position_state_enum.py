from enum import Enum

'''
Position move therefore stops from Entry to trailing
'''
class PositionState(Enum):
    Entry = 0
    Target_1 = 1
    Target_2 = 2
    Target_3 = 3
    Target_4 = 4
    Trailing = 5