from dataclasses import dataclass

import ccxt

from src.tg_bingx_bot.dataclasses.position import Position

from src.tg_bingx_bot.dataclasses.signal import Signal

@dataclass
class ExchangeConnection:
    name: str
    exchange: ccxt.Exchange
    deposit_percent_per_position: float
    leverage: int
    actual_signals: dict[str, Signal]
    positions: dict[str, Position]
    