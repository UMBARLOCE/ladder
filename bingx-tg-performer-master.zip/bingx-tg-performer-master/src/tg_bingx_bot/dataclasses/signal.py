from dataclasses import dataclass
import datetime

from src.tg_bingx_bot.dataclasses.direction_enum import Direction


@dataclass()
class Signal:
    direction: Direction
    symbol: str
    receive_time: datetime.datetime
    min_enter_price: float
    max_enter_price: float
    target_1_price: float
    target_2_price: float
    target_3_price: float
    target_4_price: float
    stop_loss_price: float