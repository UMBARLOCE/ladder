from dataclasses import dataclass

@dataclass
class KeyPair:
    name: str
    deposit_percent_per_position: float
    leverage: int
    public: str
    private: str