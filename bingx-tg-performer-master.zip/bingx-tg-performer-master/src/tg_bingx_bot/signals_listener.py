import asyncio
import datetime
import logging
import os
import signal
from pprint import pprint
from typing import NoReturn, Callable, Coroutine

import aiogram
from aiogram import Router
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message

from src.tg_bingx_bot.dataclasses.direction_enum import Direction
from src.tg_bingx_bot.dataclasses.signal import Signal

logger = logging.getLogger(__name__)

class Listener:
    def __init__(self, bot_token: str, channel_id: int, signal_callback: Callable[[Signal], Coroutine]):
        logger.info("Init telegram bot")
        self._bot = aiogram.Bot(token=bot_token)
        self._dp = aiogram.Dispatcher(storage=MemoryStorage())
        self._channel_id = channel_id
        self._router = Router()

        self._signal_callback = signal_callback

        self._dp.channel_post.register(self._channel_post_handler)

    async def close(self):
        await self._dp.stop_polling()
        await self._bot.close()

    async def start_polling(self, loop: asyncio.AbstractEventLoop) -> NoReturn:
        if os.name == 'posix':
            loop.add_signal_handler(signal.SIGTERM, lambda: asyncio.ensure_future(self.close()))
            loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(self.close()))

        logger.info("Start polling")

        await self._dp.start_polling(self._bot)

        await self._bot.close()

    async def _channel_post_handler(self, message: Message):
        try:
            if message.chat.id == self._channel_id:
                logger.info(f"Telegram: received new signal")
                signal = self.parse_signal(message.text, message.date)
                await self._signal_callback(signal)
        except Exception as exc:
            logger.error(f"Problem with parsing signal {exc}. Message text:\n{message.text}", exc_info=True)


    @staticmethod
    def parse_signal(signal_str: str, message_date: datetime) -> Signal:
        parts = [line.split() for line in signal_str.split('\n')]
        return Signal(
            direction=Direction.BUY if parts[0][0].upper() == "BUY" else Direction.SELL,
            symbol=parts[0][1],
            receive_time=message_date,
            min_enter_price=float(parts[1][0]),
            max_enter_price=float(parts[1][2] if len(parts[1]) == 3 else parts[1][0]),
            target_1_price=float(parts[2][1]),
            target_2_price=float(parts[3][1]),
            target_3_price=float(parts[4][1]),
            target_4_price=float(parts[5][1]),
            stop_loss_price=float(parts[6][1])
        )
