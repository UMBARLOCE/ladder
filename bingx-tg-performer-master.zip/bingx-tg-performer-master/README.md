# BingX Performer TG Bot

Бот для исполнения сигналов из телеграм формата

```
BUY MKRUSDT
2423.6 - 2445.2
t1 2462.2
t2 2513.3
t3 2564.4
t4 2615.6
sl 2293.9
```

- t1: стоп переносим на минимальную цену точки входа
- t2: закрываем половину позиции, стоп на цену входа
- t3: стоп переносим на первый таргет
- t4: закрываем половину позиции (25% от изначального объема), включаем трейлинг стоп

## Развертывание
Для работы потребуются пакеты python3.11, python3.11-venv, git. Развертывание тестировалось на Ubuntu 24.04

Подготовка:
```bash
sudo apt-get update && sudo apt-get upgrade
sudo apt-get install python3.11 python3.11-venv git
```

Клонировать репозиторий

```bash
git clone https://github.com/khanbekov/bingx-tg-performer.git ./bingx-tg-performer
```

Перейти в директорию

```bash
cd bingx-tg-performer
```

Создать и активировать виртуальную среду Python

```bash
python3.11 -m venv venv
source venv/bin/activate
```

Установить зависимости
```bash
pip install -r requirements.txt
```

После этого можно начинать работу. Я советую создать демона для systemd, т.к. это самый простой и лаконичный вариант. 
С помощью него бот будет работать фоново, а вы сможете подключаться и читать его логи, остпнавливать или перезапускать.

Создайте файл конфигурации для запуска сервиса:
```bash
sudo nano /etc/systemd/system/bingx_bot.service
```

Не выходя из редактора, скопируйте и вставьте следующую конфигурацию:

```yaml
[Unit]
Description=Bingx Telegram Performer Bot
After=network.target

[Service]
User=user
WorkingDirectory=/home/user/bingx-tg-performer
ExecStart=/home/user/bingx-tg-performer/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

После этого можно запустить сервис:

```bash
sudo systemctl start bingx_bot
```

Просмотреть логи в реальном времени:

```bash
sudo journalctl -eu bingx_bot
```