import pytest

from src.tg_bingx_bot.utils import check_to_range, round_to_precision


class TestCheckToRange:
    def test_check_value_into_range(self):
        value = 5
        up_bound = 10
        down_bound = 1

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_up_bound(self):
        value = 10
        up_bound = 10
        down_bound = 1

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_down_bound(self):
        value = 1
        up_bound = 10
        down_bound = 1

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_up_float_bound(self):
        value = 0.3333
        up_bound = 0.3333
        down_bound = 0.3332

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_zero_range(self):
        value = 0
        up_bound = 0
        down_bound = 0

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_negative_range(self):
        value = -5
        up_bound = -1
        down_bound = -10

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_only_up_bound(self):
        value = -10
        up_bound = 0
        down_bound = None

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_only_down_bound(self):
        value = 10
        up_bound = None
        down_bound = 9

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_on_no_range(self):
        value = 10
        up_bound = None
        down_bound = None

        expected = True

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_out_of_up_bound(self):
        value = 11
        up_bound = 10
        down_bound = 1

        expected = False

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_out_of_down_bound(self):
        value = 0
        up_bound = 10
        down_bound = 1

        expected = False

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_out_of_only_down_bound(self):
        value = 0
        up_bound = None
        down_bound = 1

        expected = False

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected

    def test_check_value_out_of_only_up_bound(self):
        value = 11
        up_bound = 10
        down_bound = None

        expected = False

        result = check_to_range(
            value=value,
            up_bound=up_bound,
            down_bound=down_bound
        )
        assert result == expected


class TestRoundToPrecisin:
    def test_round_to_precision_one_digit(self):
        value = 1.111
        precision = 0.01

        expected = 1.11

        result = round_to_precision(
            value=value,
            precision=precision
        )
        assert result == expected

    def test_round_to_precision_value_two_digit(self):
        value = 1.111
        precision = 0.1

        expected = 1.1

        result = round_to_precision(
            value=value,
            precision=precision
        )
        assert result == expected

    def test_round_to_precision_value_to_int(self):
        value = 1.111
        precision = 1

        expected = 1

        result = round_to_precision(
            value=value,
            precision=precision
        )
        assert result == expected

    def test_round_to_precision_value_to_decimal(self):
        value = 111.111
        precision = 10

        expected = 110

        result = round_to_precision(
            value=value,
            precision=precision
        )
        assert result == expected
    def test_round_to_precision_value_to_decimal_round_error(self):
        value = 0.1088
        precision = 0.00000001

        expected = 0.1088

        result = round_to_precision(
            value=value,
            precision=precision
        )
        assert result == expected
    def test_round_to_precision_value_to_decimal_round_error_with_ceil(self):
        value = 0.1088
        precision = 0.00000001
        use_ceil = True

        expected = 0.1088

        result = round_to_precision(
            value=value,
            precision=precision,
            use_ceil=use_ceil
        )
        assert result == expected
